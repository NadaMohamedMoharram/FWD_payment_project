/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/

#ifndef PORT_INTERFACE_H_
#define PORT_INTERFACE_H_

/*
 * Prototype   : void PORT_voidInit(void);
 * Description : set all PORTS Direction
 * Arguments   : void
 * return      : void
 */
void PORT_voidInit(void);



#endif /* PORT_INTERFACE_H_ */
