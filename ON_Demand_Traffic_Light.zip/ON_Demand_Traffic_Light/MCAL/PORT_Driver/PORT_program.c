/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/

#include "../PORT_Driver/PORT_config.h"
#include "../PORT_Driver/PORT_interface.h"
#include "../PORT_Driver/PORT_private.h"
#include "../PORT_Driver/PORT_register.h"
#include "../PORT_Driver/STD_TYPES.h"


/*
 * Prototype   : void PORT_voidInit(void);
 * Description : set all PORTS Direction
 * Arguments   : void
 * return      : void
 */

void PORT_voidInit(void){


	DDRA =PORTA_DIR;
	DDRB =PORTB_DIR;
	DDRC =PORTC_DIR;
	DDRD =PORTD_DIR;

	PORTA =PORTA_INITIAL_VALUE;
	PORTB =PORTB_INITIAL_VALUE;
	PORTC =PORTC_INITIAL_VALUE;
	PORTD =PORTD_INITIAL_VALUE;

}
