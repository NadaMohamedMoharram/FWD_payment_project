/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/


#include "../GIE_Driver/BIT_MATH.h"
#include "../GIE_Driver/GIE_interface.h"
#include "../GIE_Driver/GIE_register.h"
#include "../GIE_Driver/STD_TYPES.h"

void GIE_voidEnable(void)
{
	SETBIT(SREG,SREG_I);
}

void GIE_voidDisable(void)
{
	CLRBIT(SREG,SREG_I);
}
