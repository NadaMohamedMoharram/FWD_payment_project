/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/

#ifndef _BIT_MATH_H
#define _BIT_MATH_H

#define SETBIT(VAR,BITNO) (VAR) |=  (1 << (BITNO))
#define CLRBIT(VAR,BITNO) (VAR) &= ~(1 << (BITNO))
#define TOGBIT(VAR,BITNO) (VAR) ^=  (1 << (BITNO))
#define GETBIT(VAR,BITNO) (((VAR) >> (BITNO)) & 0x01)


#endif
