/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/

#ifndef TIMER_INTERFACE_H_
#define TIMER_INTERFACE_H_


/*
 * Prototype   : void TIMER_voidTimer0Init(void);
 * Description :  initialize Timer 0 in normal mode.
 * Arguments   : void
 * return      : void
 */
void TIMER_voidTimer0Init(void);

/*
 * Prototype   : void TIMER_voidTimer0Init(void);
 * Description :  make a delay with 256 pre-scaler.
 * Arguments   : Copy_u32Delay_ms
 * return      : void
 */

void TIMER_voidTimer0Delay(u32 Copy_u32Delay_ms);

#endif /* TIMER_INTERFACE_H_ */
