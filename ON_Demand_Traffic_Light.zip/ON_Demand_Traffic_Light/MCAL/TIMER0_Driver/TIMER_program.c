/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/
/*include Lib Files*/
#include <math.h>
#include "../TIMER0_Driver/BIT_MATH.h"

#include "../TIMER0_Driver/BIT_MATH.h"
#include "../TIMER0_Driver/BIT_MATH.h"
#include "../TIMER0_Driver/BIT_MATH.h"
#include "../TIMER0_Driver/BIT_MATH.h"
#include "../TIMER0_Driver/BIT_MATH.h"
#include "../TIMER0_Driver/STD_TYPES.h"
#include "../TIMER0_Driver/TIMER_interface.h"
#include "../TIMER0_Driver/TIMER_interface.h"
#include "../TIMER0_Driver/TIMER_register.h"


/*
 * ==============================================================================================================
 * TCCR0/2 = Timer/Counter Control Register
 * 		   > bit-7 FOC0 = Forced Compare Match >> used in Non-PWM modes
 * 				          if set > jump to ISR before the time specified
 *
 * 		   > bit-3:6  WGM00:01 = Waveform Generation Mode
 * 		     WGM01    WGM00     Mode of Operation        TOP
 * 		       0        0         Normal Mode            0xFF
 * 		       0        1         PWM Phase Correct      0xFF
 * 		       1        0         CTC                    OCR0 value
 * 		       1        1         Fast PWM               0xFF
 *
 *
 *         > bit-5:4  COM01:0 = Compare Match Output Mode
 *           uses the hardware pin of OC0 > the pin direction must be set as OUTPUT
 *				COM01   COM00   Description >> NON-PWM Modes
 *				  0       0     Normal Port Operation (OC0 Disconnected)
 *				  0       1     Toggle OC0 on Compare Match
 *				  1       0     Clear OC0 on Compare Match
 *				  1       1     Set   OC0 on Compare Match
 *
 *
 *		  > bits-2:0 CS02:0 = Clock Selection
 *		       CS02    CS01   CS00   Description
 *		        0       0      0     No CK source, Timer Disconnected
 *		        0       0      1     Same CK of system (No Prescaling)
 *		        0       1      0     CK/ 8 (Prescaler 8)
 *		        0       1      1     CK/64  (Prescaler 64)
 *		        1       0      0     CK/256 (Prescaler 256)
 *		        1       0      1     CK/1024 (Prescaler 1024)
 *		        1       1      0     External CK Source on T0 pin, CK on Falling Edge
 *		        1       1      1     External CK Source on T0 pin, CK on Rising Edge
 *
 * TIMSK0/2 = Timer/Counter Interrupt Mask Register
 *          > bit-1 > OCIE0 = Timer Output Compare Match Interrupt Enable
 *                    When set and SREG I-bit is set also, this enable the interrupt that
 *                    happens when the flag is raised (Timer done counting)
 *
 *          > bit-0 > TOIE = Timer Overflow Interrupt Enable
 *                    When set and SREG I-bit is set also, this enable the interrupt that
 *                    happens when the flag is raised (Timer done counting)
 *
 *
 * TIFR0/2 = Timer/Counter Interrupt Flag Register
 *         > bit-1 > OCF0 = Output Compare Flag
 *           Cleared by hardware when the interrupt is done or by Setting it with 1
 *           SREG I-bit set, OCIE set and OCF is 1 > Interrupt executes
 *
 *         > bit-0 > TOV0 = Timer Overflow Flag
 *           Cleared by hardware when the interrupt is done or by Setting it with 1
 *           SREG I-bit set, OCIE set and OCF is 1 > Interrupt executes
 *           ======================================================================================
 */


/*
 * Prototype   : void TIMER_voidTimer0Init(void);
 * Description :  initialize Timer 0 in normal mode.
 * Arguments   : void
 * return      : void
 */
void TIMER_voidTimer0Init(void)
{
	/*Normal mode to TIMER0*/
	CLRBIT(TCCR0,TCCR0_WGM00);
	CLRBIT(TCCR0,TCCR0_WGM01);
}

/*
 * Prototype   : void TIMER_voidTimer0Init(void);
 * Description :  make a delay with 256 pre-scaler.
 * Arguments   : Copy_u32Delay_ms
 * return      : void
 */

void TIMER_voidTimer0Delay(u32 Copy_u32Delay_ms)
{
	CLRBIT(TCCR0, TCCR0_CS00);
	CLRBIT(TCCR0, TCCR0_CS01);
	SETBIT(TCCR0, TCCR0_CS02);

	f64 Local_f64TickTime= 256.0/10000.0;
	f64 Local_f64DelayMax= Local_f64TickTime *(1<<8);
	u32 Local_u32TimerInitValue;
	u32 Local_u32NumOV;
	u32 Local_u32OverflowCounter = 0;

	if(Copy_u32Delay_ms < Local_f64DelayMax)
	{
		Local_u32TimerInitValue = (Local_f64DelayMax - Copy_u32Delay_ms)/Local_f64TickTime;
		/*Set initial timer value*/
		TCNT0 = Local_u32TimerInitValue;
		/*Busy waiting*/
		while(GETBIT(TIFR,TIFR_TOV0) == 0);
		/*Clear the flag*/
		SETBIT(TIFR,TIFR_TOV0);

	}
	else if(Copy_u32Delay_ms == Local_f64DelayMax)
	{
		/*Set initial timer value*/
		TCNT0 = 0x00;
		/*Busy waiting*/
		while(GETBIT(TIFR,TIFR_TOV0) == 0);
		/*Clear the flag*/
		SETBIT(TIFR,TIFR_TOV0);
	}
	else
	{
		Local_u32NumOV = ceil(Copy_u32Delay_ms/Local_f64DelayMax);
		Local_u32TimerInitValue =(1<<8) - ((Copy_u32Delay_ms/Local_f64TickTime) / Local_u32NumOV);
		/*Set initial timer value*/
		TCNT0 = Local_u32TimerInitValue;

		while(Local_u32OverflowCounter < Local_u32NumOV)
		{
			/*Busy waiting*/
			while(GETBIT(TIFR,TIFR_TOV0) == 0);
			/*Clear the flag*/
			SETBIT(TIFR,TIFR_TOV0);

			Local_u32OverflowCounter++;
		}

	}

	/*Timer Stop*/
	TCCR0 = 0x00;
}
