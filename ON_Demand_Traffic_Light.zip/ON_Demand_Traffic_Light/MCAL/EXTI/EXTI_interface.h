/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/
#include "BIT_MATH.h"
#include "STD_TYPES.h"
#ifndef EXTI_INTERFACE_H_
#define EXTI_INTERFACE_H_

#define INT_LOW_LEVEL            1
#define INT_LOGICAL_CHANGE       2
#define INT_FALLING_EDGE         3
#define INT_RISING_EDGE          4
#define EXTI_INT0                 5
#define EXTI_INT1                 6
#define EXTI_INT2                 7
#define GISR_ENEBLE               9
#define GISR_DISEBLE              10




/*Function Prototypes*/

/*
 * Prototype   : void EXTI_voidInt0Init(void);
 * Description : Initialize  INT0 using pre processing directive [ Mood , Status]
 * Arguments   : void
 * return      : void
 */
void EXTI_voidInt0Init(void);


/*Function Prototypes*/

/*
 * Prototype   : void EXTI_voidInt1Init(void);
 * Description : Initialize  INT1 using pre processing directive [ Mood , Status]
 * Arguments   : void
 * return      : void
 */
void EXTI_voidInt1Init(void);

/*Function Prototypes*/

/*
 * Prototype   : void EXTI_voidInt2Init(void);
 * Description : Initialize  INT2 using pre processing directive [ Mood , Status]
 * Arguments   : void
 * return      : void
 */
void EXTI_voidInt2Init(void);

/*
 * Prototype   : u8 EXTI_u8IntSetSenseControl(u8 Copy_u8SenseControlState,  u8 Copy_u8INTNum);
 * Description : Change Mood of   INT at Run time
 * Arguments   : u8 Copy_u8INTNum      [INT0, INT1, INT2]
               : u8 Copy_u8SenseControlState
                        iF choose INT0,INT1 ==> RAISING_EDGE_MOOD  FAILING_EDGE_MOOD  LOW_MOOD  ON_CHANGE_MOOD
                        iF choose INT0,INT2 ==> RAISING_EDGE_MOOD  FAILING_EDGE_MOOD
 * return      : Local_u8ErrorState
 */

void EXTI_u8IntSetSenseControl( u8 Copy_u8SenseControlState, u8 Copy_u8INTNum);



/*
 * Prototype   :u8 EXTI_u8IntGISRState(u8 Copy_u8GISRState, u8 Copy_u8INTNum);
 * Description : set Peripheral INT disable or enable using postBuild Configuration
 * Arguments   : u8 Copy_u8INTNum      [INT0, INT1, INT2]
               : u8 Copy_u8GISRState
                        GISR_ENEBLE,GISR_DISEBLE
                        EXTI_INT0,EXTI_INT1,EXTI_INT2
 * return      : Local_u8ErrorState
 */

void EXTI_u8IntGISRState(u8 Copy_u8GISRState, u8 Copy_u8INTNum);


/*
 * Prototype   : u8 EXTI_voidInt0SetCallBack(void (*Copy_vpInt0Func)(void));
 * Description : Set Call Back Func  of   INT0 at Run time &Handled INT0_ISR function that user write it
 * Arguments   : *Copy_vpInt0Func
               : void(* Copy_CallBackFunc)(void)     pointer point To Call Back Func
 * return      : Local_u8ErrorState
 */
u8 EXTI_voidInt0SetCallBack(void (*Copy_vpInt0Func)(void));

/*
 * Prototype   : u8 EXTI_voidInt1SetCallBack(void (*Copy_vpInt1Func)(void));
 * Description : Set Call Back Func  of   INT1 at Run time &Handled INT1_ISR function that user write it
 * Arguments   : *Copy_vpInt1Func
               : void(* Copy_CallBackFunc)(void)     pointer point To Call Back Func
 * return      : Local_u8ErrorState
 */
u8 EXTI_voidInt1SetCallBack(void (*Copy_vpInt1Func)(void));

/*
 * Prototype   : u8 EXTI_voidInt2SetCallBack(void (*Copy_vpInt2Func)(void));
 * Description : Set Call Back Func  of   INT0 at Run time &Handled INT2_ISR function that user write it
 * Arguments   : *Copy_vpInt2Func
               : void(* Copy_CallBackFunc)(void)     pointer point To Call Back Func
 * return      : Local_u8ErrorState
 */
u8 EXTI_voidInt2SetCallBack(void (*Copy_vpInt2Func)(void));

#endif /* EXTI_INTERFACE_H_ */





