
/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   MCAL   ====================================*/
/**************************************************************************/

#ifndef EXTI_CONFIG_H_
#define EXTI_CONFIG_H_



/*
                      -----------------------
                PB0   | 1                40 |
                PB1   | 2                39 |
        (INT2)  PB2   | 3                38 |
                PB3   | 4                37 |
                PB4   | 5                36 |
                PB5   | 6                35 |
                PB6   | 7                34 |
                PB7   | 8                33 |
                      | 9                32 |
                      | 10               31 |
                      | 11               30 |
                      | 12               29 |
                      | 13               28 |
                PD0   | 14               27 |
                PD1   | 15               26 |
         (INT0) PD2   | 16               25 |
         (INT1) PD3   | 17               24 |
                PD4   | 18               23 |
                PD5   | 19               22 |
                PD6   | 20               21 |
                      -----------------------

 */

/*chose:
/*Interrupt moods*/
/*
 Options of INT0,INT1:
     RAISING_EDGE_MOOD  FAILING_EDGE_MOOD  LOW_MOOD  ON_CHANGE_MOOD
 Options of INT2
      RAISING_EDGE_MOOD  FAILING_EDGE_MOOD
   */
#define INT0_SENCE_CONTROL_STATE           INT0_FALLING_EDGE

#define INT1_SENCE_CONTROL_STATE           INT1_FALLING_EDGE

#define INT2_SENCE_CONTROL_STATE           INT2_FALLING_EDGE

/*chose:
/*Interrupt status*/
/*
 Options :
    Enable
    Disable
*/

#define GISR_STATE                         GISR_ENEBLE

#endif /* EXTI_CONFIG_H_ */
