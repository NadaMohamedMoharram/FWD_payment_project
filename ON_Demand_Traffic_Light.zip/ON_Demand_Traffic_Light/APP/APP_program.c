/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   APP   ====================================*/
/**************************************************************************/
/*LIB includes */
#include "../APP/APP_interface.h"
#include "../HAL/LED/LED_interface.h"
#include "../HAL/SWITCH/SW_interface.h"
#include "../LIB/STD_TYPES.h"
#include "../LIB/BIT_MATH.h"
#include "../MCAL/DIO_Driver/DIO_interface.h"
#include "../MCAL/EXTI/EXTI_interface.h"
#include "../MCAL/GIE_Driver/GIE_interface.h"
#include "../MCAL/PORT_Driver/PORT_interface.h"
#include "../MCAL/TIMER0_Driver/TIMER_interface.h"
/*HAL includes */
/*All application logic*/
u8 APP_voidStart(void);

/*Pedestrian Mode logic*/
u8 APP_voidPedestrianMode(void);

/*end of logic*/
u8 APP_voidFinish(void);
/*Car LEDs objects of LED structure*/
LED_STRUCT CAR_RED_LED    = {DIO_u8PORTA, DIO_u8PIN0,LED_SOURCE};
LED_STRUCT CAR_GREEN_LED  = {DIO_u8PORTA, DIO_u8PIN1,LED_SOURCE};
LED_STRUCT CAR_YELLOW_LED = {DIO_u8PORTA, DIO_u8PIN2,LED_SOURCE};

/*Pedestrian LEDs objects of LED structure*/
LED_STRUCT PEDESTRIAN_RED_LED    = {DIO_u8PORTC, DIO_u8PIN0,LED_SOURCE};
LED_STRUCT PEDESTRIAN_GREEN_LED  = {DIO_u8PORTC, DIO_u8PIN1,LED_SOURCE};
LED_STRUCT PEDESTRIAN_YELLOW_LED = {DIO_u8PORTC, DIO_u8PIN1,LED_SOURCE};

/*push button structure*/
SW_Type ISR_SW = {DIO_u8PORTD, DIO_u8PIN2,SW_Int_PULL_UP};

/*car LED State*/
LED_STATE_t carRed_LED    = LED_IDLE;
LED_STATE_t carGreen_LED  = LED_IDLE;
LED_STATE_t carYellow_LED = LED_IDLE;

/*pedestrian LED State*/
LED_STATE_t pedesRed_LED    = LED_IDLE;
LED_STATE_t pedesGreen_LED  = LED_IDLE;
LED_STATE_t pedesYellow_LED = LED_IDLE;

/*initial mode state*/
MODE_t MODE_STATUS = NORMAL_MODE;

/*all Initials I need */
void APP_voidInit(void)
{
	PORT_voidInit();
	TIMER_voidTimer0Init();
	EXTI_u8IntSetSenseControl(INT_FALLING_EDGE, EXTI_INT0);
	EXTI_u8IntGISRState(GISR_ENEBLE, EXTI_INT0);
	EXTI_voidInt0SetCallBack(&INT0_ISR);
	GIE_voidEnable();
	SW_voidInit(ISR_SW);
}

/*All application logic*/
u8 APP_voidStart(void)
{
	/*return error state*/
	u8 LOC_u8Error=0;
	/*check Mode state, normal or Pedestrian*/
	switch(MODE_STATUS)
	{
	/*if mode is normal*/
	case NORMAL_MODE:
		/*turn on Car Red LED for 5SEC*/
		LED_u8LED_ON(CAR_RED_LED);
		carRed_LED = LED_ACTIVE ;
		TIMER_voidTimer0Delay(5000);
		/*turn off Car Red LED*/
		LED_u8LED_OFF(CAR_RED_LED);
		carRed_LED = LED_IDLE ;

		/*turn on Car Green LED for 5SEC*/
		LED_u8LED_ON(CAR_GREEN_LED);
		carGreen_LED = LED_ACTIVE ;
		TIMER_voidTimer0Delay(5000);
		/*turn off Car Green LED*/
		LED_u8LED_OFF(CAR_GREEN_LED);
		carGreen_LED = LED_IDLE ;

		/*blanking Car yellow LED for 5sec*/
		for(u8 counter=0; counter<5;counter++)
		{
			LED_u8LED_ON(CAR_YELLOW_LED);
			carYellow_LED = LED_ACTIVE ;
			TIMER_voidTimer0Delay(500);
			LED_u8LED_OFF(CAR_YELLOW_LED);
			TIMER_voidTimer0Delay(500);
		}
		carYellow_LED = LED_IDLE ;
		break;
		/*if mode is pedestrian call the pedestrian function*/
	case PEDESTRIAN_MODE: APP_voidPedestrianMode(); break;
	default : LOC_u8Error=1; break;
	}

	/*return to normal mode*/
	MODE_STATUS = NORMAL_MODE ;
	APP_voidStart();

	/*return error state*/
	return LOC_u8Error;
}


/*Pedestrian Mode logic*/
u8 APP_voidPedestrianMode(void)
{
	/*return error state*/
	u8 LOC_u8Error=0;
	/*turn off all LEDs*/
	LED_u8LED_OFF(CAR_RED_LED);
	LED_u8LED_OFF(CAR_YELLOW_LED);
	LED_u8LED_OFF(CAR_GREEN_LED);
	LED_u8LED_OFF(PEDESTRIAN_RED_LED);
	LED_u8LED_OFF(PEDESTRIAN_YELLOW_LED);
	LED_u8LED_OFF(PEDESTRIAN_GREEN_LED);


	if(carRed_LED == LED_ACTIVE)
	{
		/*turn on pedestrian Green and Car Red LEDs for 5 SEC*/
		LED_u8LED_ON(PEDESTRIAN_GREEN_LED);
		LED_u8LED_ON(CAR_RED_LED);
		TIMER_voidTimer0Delay(5000);
		LED_u8LED_OFF(PEDESTRIAN_GREEN_LED);
		LED_u8LED_OFF(CAR_RED_LED);
	}
	/*check if Car Green or Yellow LEDs Active*/
	else if((carGreen_LED == LED_ACTIVE) || (carYellow_LED == LED_ACTIVE))
	{
		/*blinking for 5 SEC to start pedestrian mode*/
		for(u8 counter=0; counter<5;counter++)
		{
			LED_u8LED_ON(PEDESTRIAN_YELLOW_LED);
			LED_u8LED_ON(CAR_YELLOW_LED);
			TIMER_voidTimer0Delay(500);
			LED_u8LED_OFF(PEDESTRIAN_YELLOW_LED);
			LED_u8LED_OFF(CAR_YELLOW_LED);
			TIMER_voidTimer0Delay(500);
		}
		/*turn off yellows after blanking*/
		LED_u8LED_OFF(PEDESTRIAN_YELLOW_LED);
		LED_u8LED_OFF(CAR_YELLOW_LED);

		/*turn on Pedestrian Green LED to Pedestrian passing*/
		LED_u8LED_ON(PEDESTRIAN_GREEN_LED);
		LED_u8LED_ON(CAR_RED_LED);
		TIMER_voidTimer0Delay(5000);
		LED_u8LED_OFF(PEDESTRIAN_GREEN_LED);
		LED_u8LED_OFF(CAR_RED_LED);

	}else
	{
		LOC_u8Error=1;
	}
	/*call this function to start turn off pedestrian mode*/
	APP_voidFinish();

	/*return error state*/
	return LOC_u8Error;
}

/*end of logic*/
u8 APP_voidFinish(void)
{
	/*return error state*/
	u8 LOC_u8Error=0;

	/*blink yellows to stop pedestrian mode*/
	for(u8 counter=0; counter<5;counter++)
	{
		LED_u8LED_ON(PEDESTRIAN_YELLOW_LED);
		LED_u8LED_ON(CAR_YELLOW_LED);
		TIMER_voidTimer0Delay(500);
		LED_u8LED_OFF(PEDESTRIAN_YELLOW_LED);
		LED_u8LED_OFF(CAR_YELLOW_LED);
		TIMER_voidTimer0Delay(500);
	}
	/*stop planking*/
	LED_u8LED_OFF(PEDESTRIAN_YELLOW_LED);
	LED_u8LED_OFF(CAR_YELLOW_LED);

	/*ready to back to normal mode*/
	LED_u8LED_OFF(PEDESTRIAN_GREEN_LED);
	LED_u8LED_ON(PEDESTRIAN_RED_LED);
	LED_u8LED_ON(CAR_GREEN_LED);
	TIMER_voidTimer0Delay(5000);

	/*turn off all LEDs*/
	LED_u8LED_OFF(CAR_RED_LED);
	LED_u8LED_OFF(CAR_YELLOW_LED);
	LED_u8LED_OFF(CAR_GREEN_LED);
	LED_u8LED_OFF(PEDESTRIAN_RED_LED);
	LED_u8LED_OFF(PEDESTRIAN_YELLOW_LED);
	LED_u8LED_OFF(PEDESTRIAN_GREEN_LED);

	/*back to normal mode*/
	MODE_STATUS = NORMAL_MODE ;
	APP_voidStart();

	/*return error state*/
	return LOC_u8Error;
}

/*ISR function*/
void INT0_ISR(void)
{
	MODE_STATUS = PEDESTRIAN_MODE;
	APP_voidStart();
}
