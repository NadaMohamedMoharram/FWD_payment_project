
/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   HAL   ====================================*/
/**************************************************************************/
#ifndef LED_INTERFACE_H_
#define LED_INTERFACE_H_
#include "STD_TYPES.h"
#include "BIT_MATH.h"

/*LED Connection Type defines*/
#define LED_SINK       0
#define LED_SOURCE     1

/*LED Structure*/

typedef struct
{
	u8 port;
	u8 pin;
	u8 type;
}LED_STRUCT;

/************************************************************************************
 * Function Name: LED_u8LED_ON
 * Parameters (in): (LED_STRUCT Copy_u8LEDt - object from LED_STRUCT structure
 * Parameters (out): LOCAL_u8ERROR
 * Description: Function to  Turn ON the LED
 ************************************************************************************/
u8 LED_u8LEDOn(LED_STRUCT Copy_u8LED);

/************************************************************************************
 * Function Name: LED_u8LED_OFF
 * Parameters (in): (LED_STRUCT Copy_u8LEDt - object from LED_STRUCT structure
 * Parameters (out): LOCAL_u8ERROR
 * Description: Function to  Turn Off the LED
 ************************************************************************************/
u8 LED_u8LEDOff(LED_STRUCT Copy_u8LED);


/************************************************************************************
 * Function Name: LED_u8LED_ON
 * Parameters (in): -LED_STRUCT Copy_u8LEDt - object from LED_STRUCT structure
 *                  -u32 Copy_u32Delay_ms
 * Parameters (out): LOCAL_u8ERROR
 * Description: Function to  Toggle the LED .
 ************************************************************************************/
u8 LED_u8Toggle(LED_STRUCT Copy_u8LED, u32 Copy_u32Delay_ms);


#endif /* LED_INTERFACE_H_ */
