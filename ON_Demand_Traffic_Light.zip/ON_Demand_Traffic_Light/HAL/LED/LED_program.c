
/**********************************************************************/
/**================   Author:  Nada Mohamed  ========================**/
/*=================   LAYER:   HAL   ====================================*/
/**************************************************************************/


#include "../../HAL/LED/BIT_MATH.h"
#include "../../HAL/LED/LED_interface.h"
#include "../../HAL/LED/LED_private.h"
#include "../../HAL/LED/STD_TYPES.h"
#include "../../MCAL/DIO_Driver/DIO_interface.h"
#include "../../MCAL/TIMER0_Driver/TIMER_interface.h"

/************************************************************************************
 * Function Name: LED_u8LED_ON
 * Parameters (in): (LED_STRUCT Copy_u8LEDt - object from LED_STRUCT structure
 * Parameters (out): LOCAL_u8ERROR
 * Description: Function to  Turn ON the LED
 ************************************************************************************/
u8 LED_u8LED_ON(LED_STRUCT Copy_u8LED)
{
	u8 LOCAL_u8ERROR=0;
	switch(Copy_u8LED.type)
	{
	case LED_SOURCE: DIO_u8SetPinValue(Copy_u8LED.port, Copy_u8LED.pin, DIO_u8PIN_HIGH);break;
	case LED_SINK:   DIO_u8SetPinValue(Copy_u8LED.port, Copy_u8LED.pin, DIO_u8PIN_LOW); break;
	default: LOCAL_u8ERROR=1; break;
	}
	return LOCAL_u8ERROR;
}

/************************************************************************************
 * Function Name: LED_u8LED_OFF
 * Parameters (in): (LED_STRUCT Copy_u8LEDt - object from LED_STRUCT structure
 * Parameters (out): LOCAL_u8ERROR
 * Description: Function to  Turn Off the LED
 ************************************************************************************/
u8 LED_u8LED_OFF(LED_STRUCT Copy_u8LED)
{
	u8 LOCAL_u8ERROR=0;
	switch(Copy_u8LED.type)
	{
	case LED_SOURCE: DIO_u8SetPinValue(Copy_u8LED.port, Copy_u8LED.pin, DIO_u8PIN_LOW); break;
	case LED_SINK:   DIO_u8SetPinValue(Copy_u8LED.port, Copy_u8LED.pin, DIO_u8PIN_HIGH);break;
	default: LOCAL_u8ERROR=1; break;
	}
	return LOCAL_u8ERROR;
}


/************************************************************************************
 * Function Name: LED_u8LED_ON
 * Parameters (in): -LED_STRUCT Copy_u8LEDt - object from LED_STRUCT structure
 *                  -u32 Copy_u32Delay_ms
 * Parameters (out): LOCAL_u8ERROR
 * Description: Function to  Toggle the LED .
 ************************************************************************************/
u8 LED_u8Toggle(LED_STRUCT Copy_u8LED, u32 Copy_u32Delay_ms)
{
	u8 LOCAL_u8ERROR=0;
	u8 Local_u8PinState;
	DIO_u8GetPinValue(Copy_u8LED.port,Copy_u8LED.pin,&Local_u8PinState);

	switch(Copy_u8LED.type)
	{
	case LED_SOURCE:
		LED_u8LED_ON(Copy_u8LED);
		TIMER_voidTimer0Delay(Copy_u32Delay_ms);
		LED_u8LED_OFF(Copy_u8LED);
		TIMER_voidTimer0Delay(Copy_u32Delay_ms);
		break;
	case LED_SINK:
		LED_u8LED_OFF(Copy_u8LED);
		TIMER_voidTimer0Delay(Copy_u32Delay_ms);
		LED_u8LED_ON(Copy_u8LED);
		TIMER_voidTimer0Delay(Copy_u32Delay_ms);
		break;
	default: LOCAL_u8ERROR=1;          break;
	}
	return LOCAL_u8ERROR;
}

