
#include <stdio.h>
#include <string.h>
#include "server.h"


ST_terminalData_t terminalData;
ST_cardData_t card;
ST_accountsDB_t accountRefrence;
/*======================================================
Array of ST_accountsDB_t for the valid accounts database.
======================================================*/
static ST_accountsDB_t accountDB[255] =
{
    {1000.0  ,BLOCKED, "82185078034948991109"},
	{1500.5  ,BLOCKED, "09253380667255600309"},
	{1010.0  ,RUNNING, "30274863452705182821"},
	{140000.0 ,RUNNING,"76717186807866961859"},
	{15500.5 ,BLOCKED, "46238627076743124755"},
	{2990.0  ,RUNNING, "88977643030925405946"},
	{2500.0   ,RUNNING,"38005588641605043820"},
	{459000.0,BLOCKED, "66462896070101377264"},
	{500  ,RUNNING,"99081311034039196933"},
	{59500.0 ,BLOCKED, "09885843713809799324"}
};

ST_transaction_t transactionsDB[255] = { 0 };
uint8_t SavedAcountNo;
float balance;
uint32_t SeqNo = 0;


/************************************************************************************************
This function will take card data and validate if the account related to this card exists or not.
It checks if the PAN exists or not in the server's database (searches for the card PAN in the DB).
If the PAN doesn't exist will return ACCOUNT_NOT_FOUND and the account reference will be NULL, else will return SERVER_OK and return a reference to this account in the DB.
 ************************************************************************************************/
EN_serverError_t isValidAccount(ST_cardData_t* cardData)
{
	EN_serverError_t errorState = SERVER_OK;

	uint32_t counter;
	for (counter = 0; counter < 255; counter++)
	{
		if (strcmp((accountDB[counter].primaryAccountNumber), (cardData->primaryAccountNumber)) == 0)
		{
			SavedAcountNo = counter;
			errorState = SERVER_OK;
			break;

		}
		else
		{
			errorState = ACCOUNT_NOT_FOUND;
		}
	}
	return errorState;
}

/**********************************************************************************************************
This function takes a reference to the account into the database and verifies if it is blocked or not.
If the account is running it will return SERVER_OK, else if the account is blocked it will return BLOCKED_ACCOUNT.
 *************************************************************************************************************/
EN_serverError_t isBlockedAccount(ST_accountsDB_t* ST_accountsDB_t)
{
	EN_serverError_t errorState = SERVER_OK;

	if ((accountDB[SavedAcountNo].state) == BLOCKED)
	{
		errorState = BLOCKED_ACCOUNT;

	}
	else
	{
		errorState = SERVER_OK;
	}
	return errorState;
}

/*************************************************************************************
This function will take terminal data and a reference to the account in the database and check if the account has a sufficient amount to withdraw or not.
It checks if the transaction's amount is available or not.
If the transaction amount is greater than the balance in the database will return LOW_BALANCE, else will return SERVER_OK.
************************************************************************************* */
EN_serverError_t isAmountAvailable(ST_terminalData_t* termData)
{
	/*return check*/
	EN_serverError_t errorState = SERVER_OK;


	if ((termData->transAmount) <= (accountDB[SavedAcountNo].balance))
	{
		errorState = SERVER_OK;

	}
	else
	{
		errorState = LOW_BALANCE;
	}
	return errorState;
}

/**********************************************************************************************
This function will store all transaction data in the transactions database.
It gives a sequence number to a transaction, this number is incremented once a transaction is processed into the server, you must check the last sequence number in the server to give the new transaction a new sequence number
**********************************************************************************************/
EN_serverError_t saveTransaction(ST_transaction_t* transData)
{
	EN_serverError_t errorState = SERVER_OK;
	if (SeqNo < 255)
	{

		transData->transactionSequenceNumber = SeqNo;
		uint32_t count = transData->transactionSequenceNumber;
		transactionsDB[count].cardHolderData = transData->cardHolderData;
		transactionsDB[count].terminalData = transData->terminalData;
		transactionsDB[count].transactionSequenceNumber = transData->transactionSequenceNumber;
		transactionsDB[count].transState = transData->transState;
	
		SeqNo++; // ubdate sequance number
		errorState = SERVER_OK;
	}
	else
	{
		errorState = SAVING_FAILED;
	}

	return errorState;

}

/******************************************************************************************
 This function will take all transaction data and validate its data, it contains all server logic.
It checks the account details and amount availability.
If the account does not exist return FRAUD_CARD, if the amount is not available will return DECLINED_INSUFFECIENT_FUND, if the account is blocked will return DECLINED_STOLEN_CARD, if a transaction can't be saved will return INTERNAL_SERVER_ERROR , else returns APPROVED.
It will update the database with the new balance.
 ******************************************************************************************/

EN_transState_t recieveTransactionData(ST_transaction_t* transData)
{
	/*return check*/
	EN_serverError_t errorState = APPROVED;
	if (isValidAccount(&transData->cardHolderData) == ACCOUNT_NOT_FOUND)
	{
		transData->transState = FRAUD_CARD;
		saveTransaction(transData);
		errorState = FRAUD_CARD;
	}
	else if (isAmountAvailable(&transData->terminalData) == LOW_BALANCE)
	{
		transData->transState = DECLINED_INSUFFECIENT_FUND;
		saveTransaction(transData);
		errorState = DECLINED_INSUFFECIENT_FUND;
	}
	else if (isBlockedAccount(&accountDB[SavedAcountNo]) == BLOCKED_ACCOUNT)
	{
		transData->transState = DECLINED_STOLEN_CARD;
		saveTransaction(transData);
		errorState = DECLINED_STOLEN_CARD;
	}
	else {
		transData->transState = APPROVED;
		//printf("- - - old balance: %.3f - - -\n", accountDB[SavedAcountNo].balance);
		accountDB[SavedAcountNo].balance -= transData->terminalData.transAmount;
		balance = accountDB[SavedAcountNo].balance;
		//printf("- - - updating balance: %.3f - - -\n", accountDB[SavedAcountNo].balance);

		errorState = APPROVED;
	}


	if (saveTransaction(transData) == SAVING_FAILED)
	{
		errorState = INTERNAL_SERVER_ERROR;
	}

	return errorState;

}

