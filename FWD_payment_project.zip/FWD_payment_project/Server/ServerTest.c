#include "server.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

   ST_accountsDB_t accountRefrence;
    ST_terminalData_t terminalData;
    ST_cardData_t card;
   // ST_transaction_t transaction;
    ST_transaction_t transData;
    uint8_t state[30];
    float max = 0;
    uint8_t cardExpirationDateArray[6];

void main(void)
{

 

    printf("server module test\n");
   


        while (1) {
            ST_cardData_t* cardptr = (ST_cardData_t*)malloc(sizeof(ST_cardData_t));
            
            puts("---------------------------------------");
            /*====================================getTransactionDate Test====================================================*/

            while (getTransactionDate(&terminalData) != TERMINAL_OK) {
                printf("system date is invalid!\n");
            }
            /*====================================getCardHolderName Test====================================================*/

            while (getCardHolderName(&card) != Card_OK) {
                printf("Name must be between 20 and 24 chars!\n");
            }
            printf("%s\n", card.cardHolderName);
          
           /*====================================getCardExpiryDate Test====================================================*/

            while (getCardExpiryDate(&card) != Card_OK) {
                printf("Expiration date should be in the following form: mm/yy !\n");
            }
            printf("%s\n", card.cardExpirationDate);
           // uint8_t cardExpirationDateArray[6]; 
            strcpy_s(cardExpirationDateArray, 100, card.cardExpirationDate);

            if (isCardExpired(&card, &terminalData) == EXPIRED_CARD) {
                printf("EXPIRED_CARD!\n");
                continue;
            }
            printf("TERMINAL_OK\n");


            /*****************************/
            while (getCardPAN(&card) != Card_OK) {
                printf("wrong PAN, PAN IS 20 NUMBERS!\n");
            }
            printf("%s\n", card.primaryAccountNumber);
            /* if (isValidCardPAN(card)) {
                 printf("invalid card number!\n");
                 continue;
             }*/

             /*****************************/

            EN_serverError_t isValidAccChecker = isValidAccount(&card);
            EN_serverError_t isBlockAccChecker = isBlockedAccount(&accountRefrence);
            EN_serverError_t isAmountAvChecker = isAmountAvailable(&terminalData);

            if (ACCOUNT_NOT_FOUND == isValidAccChecker) {
                puts("=== Declined Invalid Account ===");
                continue;
            }
            else {
                if (BLOCKED_ACCOUNT == isBlockAccChecker) {
                    puts("===  Blocked Account ===");
                    continue;
                }
                else {
                    puts("============== SERVER_OK:Running Account===============");
                }
            }
            //float max = 0;
            puts("please, Enter the MAX Transaction Amount -float number-:  ");
            scanf_s(" %f", &max);
            setMaxAmount(&terminalData, max);
            getTransactionAmount(&terminalData);
            while (isBelowMaxAmount(&terminalData) == EXCEED_MAX_AMOUNT) {
                printf("exceeded max amount!!\n");
                getTransactionAmount(&terminalData);

            }

            if (LOW_BALANCE == isAmountAvailable(&terminalData)) {
                puts("- - - LOW_BALANCE - - -");
                //isAmountAvChecker = isAmountAvailable(&terminalData);
                continue;
                //exit(0);
            }
            else
                puts("=========== suffecient Funds  ============");
            
            saveTransaction(&transData);
            transData.cardHolderData = card; // UPDATE CARD_HOLDER_DATA
            transData.terminalData = terminalData; // UPDATE TERMINAL_DATA
            uint8_t recieveTransDataChecker = recieveTransactionData(&transData);

            /*check server returns and return the acount state*/
            if (FRAUD_CARD == recieveTransDataChecker) {
                puts("====== FRAUD_CARD ===");
            }
            else if (DECLINED_INSUFFECIENT_FUND == recieveTransDataChecker) {
                puts("===== DECLINED_INSUFFECIENT_FUND ====");
            }
            else if (DECLINED_STOLEN_CARD == recieveTransDataChecker) {
                puts("==== DECLINED_STOLEN_CARD ====");
            }
            else if (INTERNAL_SERVER_ERROR == recieveTransDataChecker) {
                puts("=== INTERNAL_SERVER_ERROR ===");
            }
            else if (APPROVED == recieveTransDataChecker) {
              
            }


          //  uint8_t state[30];
            switch (transData.transState) {
            case APPROVED: 					 strcpy_s(state, 100, "APPROVED"); break;
            case DECLINED_STOLEN_CARD:		 strcpy_s(state, 100, "DECLINED_STOLEN_CARD"); break;
            case DECLINED_INSUFFECIENT_FUND: strcpy_s(state, 100, "DECLINED_INSUFFECIENT_FUND"); break;
            case INTERNAL_SERVER_ERROR:		 strcpy_s(state, 100, "INTERNAL_SERVER_ERROR"); break;
            case FRAUD_CARD:                 strcpy_s(state, 100, "FRAUD_CARD"); break;
            }
            listSavedTransactions();
            /*puts("############################################");

            printf("- > Transaction Sequence: %d \n", ((transData.transactionSequenceNumber)-1)/2);
            printf("- > Transaction Date:" );
            getTransactionDate(&terminalData);
           // printf("- > Transaction Amount: %.2f \n", transData.terminalData);
            printf("- > Transaction Amount: %.2f \n", terminalData.transAmount);
            printf("- > Transaction State: %s \n", state);
            printf("- > Termninal max amount: %f \n", max);


            printf("- > Card Holder Name: %s \n", card.cardHolderName);
            printf("- > Card PAN: %s\n", card.primaryAccountNumber);
            //printf("%s\n", card.cardExpirationDate);

            printf("- > Card Expiration Date: %s \n", cardExpirationDateArray);
           // printf("- > Your Account Balance: %.2f \n", balance);
            puts("############################################");
            //exit(0);
            //listSavedTransactions();*/


        }


    }




    void listSavedTransactions(void)
    {


        puts("############################################");
        printf("- > Transaction Sequence: %d \n", ((transData.transactionSequenceNumber) - 1) / 2);
        printf("- > Transaction Date:");
        getTransactionDate(&terminalData);
        printf("- > Transaction Amount: %.2f \n", terminalData.transAmount);
        printf("- > Transaction State: %s \n", state);
        printf("- > Termninal max amount: %f \n", max);
        printf("- > Card Holder Name: %s \n", card.cardHolderName);
        printf("- > Card PAN: %s\n", card.primaryAccountNumber);
        printf("- > Card Expiration Date: %s \n", cardExpirationDateArray);
        puts("############################################");
       

    }