#define _STDC_WANT_LIB_EXT1_1
#include <stdio.h>
#include <string.h>
#include "terminal.h"
#include <time.h>
#include "../Card/card.h"

#define ASCII_ZERO '0'
#define NULL 0


/****************************************************************************************************************
This function will ask for the cardholder's name and store it into card data.
Cardholder name is 24 alphabetic characters string max and 20 min.
If the cardholder name is NULL, less than 20 characters or more than 24 will return a WRONG_NAME error, else return CARD_OK
********************************************************************************************************************/
EN_terminalError_t getTransactionDate(ST_terminalData_t* termData)
{
	EN_terminalError_t errorState = TERMINAL_OK;
	struct tm newtime;
	char am_pm[] = "AM";
	__time64_t long_time;
	char timebuf[26];
	errno_t err;

	// Get time as 64-bit integer.
	_time64(&long_time);
	// Convert to local time.
	err = _localtime64_s(&newtime, &long_time);
	if (err)
	{
		printf("Invalid argument to _localtime64_s.");
		exit(1);
	}
	if (newtime.tm_hour > 12)        // Set up extension.
		strcpy_s(am_pm, sizeof(am_pm), "PM");
	if (newtime.tm_hour > 12)        // Convert from 24-hour
		newtime.tm_hour -= 12;        // to 12-hour clock.
	if (newtime.tm_hour == 0)        // Set hour to 12 if midnight.
		newtime.tm_hour = 12;
	uint8_t day = newtime.tm_mday;
	uint8_t month = newtime.tm_mon + 1; // add 1 becuse system started from month zero->
	unsigned int year = newtime.tm_year + 1900; // add 1900 becuse system late 1900 years -_-->
	

	// Convert to an ASCII representation.
	err = asctime_s(timebuf, 26, &newtime);
	if (err)
	{
		printf("Invalid argument to asctime_s.");
		exit(1);
	}
	
	/*store a day in the array as character to set the format as required*/
	printf(" system date is  %02d/%02d/%02d \n", newtime.tm_mday, newtime.tm_mon + 1, newtime.tm_year + 1900);
	termData->transactionDate[0] = newtime.tm_mday / 10 + '0';
	termData->transactionDate[1] = newtime.tm_mday % 10 + '0';
	termData->transactionDate[2] = '/';
	termData->transactionDate[3] = (newtime.tm_mon + 1) / 10 + '0';
	termData->transactionDate[4] = (newtime.tm_mon + 1) % 10 + '0';
	termData->transactionDate[5] = '/';
	termData->transactionDate[6] = '0' + (newtime.tm_year + 1900) / 1000;
	termData->transactionDate[7] = '0' + ((newtime.tm_year + 1900) % 1000) / 100;
	termData->transactionDate[8] = '0' + ((newtime.tm_year + 1900) % 100) / 10;
	termData->transactionDate[9] = '0' + (newtime.tm_year + 1900) % 10;
	termData->transactionDate[10] = '\0';
	/*check If the transaction date is NULL, less than 10 characters or wrong format will return WRONG_DATE error, else return OK->*/
	if ((strlen(termData->transactionDate) == NULL)|| (strlen(termData->transactionDate) < 10)|| (termData->transactionDate[2] != '/')|| (termData->transactionDate[5] != '/'))
	{
		errorState = WRONG_DATE;
	}
	else {
		errorState = TERMINAL_OK;
	}
	return errorState;
}

/*******************************************************************************************************
This function compares the card expiry date with the transaction date.
If the card expiration date is before the transaction date will return EXPIRED_CARD, else return TERMINAL_OK.
**********************************************************************************************************/
EN_terminalError_t isCardExpired(ST_cardData_t* cardDate, ST_terminalData_t* terminalData)
{   //for card Data
	
	int Card_Month_Date = (cardDate->cardExpirationDate[0] - '0') * 10 + cardDate->cardExpirationDate[1] - '0';


	int Card_Year_Date = (cardDate->cardExpirationDate[3] - '0') * 10 + cardDate->cardExpirationDate[4] - '0' + 2000;

	//for terminalData
	int Terminal_Month_Date = (terminalData->transactionDate[3] - '0') * 10 + terminalData->transactionDate[4] - '0';
	int Terminal_Year_Date = (terminalData->transactionDate[6] - '0') * 1000 + (terminalData->transactionDate[7] - '0') * 100 + (terminalData->transactionDate[8] - '0') * 10 + terminalData->transactionDate[9] - '0';
	
	if ((Terminal_Year_Date == Card_Year_Date) && (Terminal_Month_Date > Card_Month_Date) || (Terminal_Year_Date > Card_Year_Date))
	{

		return EXPIRED_CARD;
	}
	return TERMINAL_OK;
}



/*******************************************************************************************************
This function asks for the transaction amount and saves it into terminal data.
If the transaction amount is less than or equal to 0 will return INVALID_AMOUNT, else return TERMINAL_OK.
**********************************************************************************************************/
EN_terminalError_t getTransactionAmount(ST_terminalData_t* termData)
{
	/*return check*/
	EN_terminalError_t errorState = TERMINAL_OK;

	/*I will ask a user to enter Transaction amount*/
	puts("please, Enter the Transaction Amount :  ");
	scanf_s(" %f", &termData->transAmount);

	/*If the transaction amount is less than or equal to 0 will return INVALID_AMOUNT, else return OK->*/
	if (termData->transAmount == NULL)
	{
		errorState = INVALID_AMOUNT;
	}
	else
	{
		errorState = TERMINAL_OK;
	}
	return errorState;
}


/*******************************************************************************************************
This function compares the transaction amount with the terminal max allowed amount.
If the transaction amount is larger than the terminal max allowed amount will return EXCEED_MAX_AMOUNT, else return TERMINAL_OK.
**********************************************************************************************************/
EN_terminalError_t isBelowMaxAmount(ST_terminalData_t* termData)
{
	EN_terminalError_t errorState = TERMINAL_OK;

	if (termData->transAmount > termData->maxTransAmount)
	{
		errorState = EXCEED_MAX_AMOUNT;
	}
	else
	{
		errorState = TERMINAL_OK;
	}
	return errorState;
}


/*******************************************************************************************************
This function takes the maximum allowed amount and stores it into terminal data.
Transaction max amount is a float number.
If transaction max amount less than or equal to 0 will return the INVALID_MAX_AMOUNT error, else return TERMINAL_OK.
**********************************************************************************************************/
EN_terminalError_t setMaxAmount(ST_terminalData_t * termData, float maxAmount)
{
	
	EN_terminalError_t errorState = TERMINAL_OK;

	
	if (maxAmount <= NULL)
	{
		errorState = INVALID_MAX_AMOUNT;
	}
	else
	{
		termData->maxTransAmount = maxAmount;
		errorState = TERMINAL_OK;
	}
	return errorState;
}