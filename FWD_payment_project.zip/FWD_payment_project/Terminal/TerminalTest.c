#include "terminal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../Card/card.h"
#include "Warningsr.h"



void main(void) {
    ST_terminalData_t* terminalData = (ST_terminalData_t*)malloc(sizeof(ST_terminalData_t));
    ST_cardData_t* card = (ST_cardData_t*)malloc(sizeof(ST_cardData_t));


    while (1) {
        /*====================================getCardHolderName Test====================================================*/

        while (getCardHolderName(card) != Card_OK) {
            printf("Name must be between 20 and 24 chars!\n");
        }

        printf("CardHolderName is :%s\n", card->cardHolderName);

        /*====================================getTransactionDate Test====================================================*/

        while (getTransactionDate(terminalData) != TERMINAL_OK) {
            printf("system date is invalid!\n");

        }

        /*====================================getCardExpiryDate Test====================================================*/

        while (getCardExpiryDate(card) != Card_OK) {
            printf("Expiration date should be in the following form: mm/yy !\n");
        }
        printf(" Expiration date is :%s\n", card->cardExpirationDate);


        if (isCardExpired(card, terminalData) == EXPIRED_CARD) {
            printf("EXPIRED_CARD!\n");
            continue;
        }
        printf("TERMINAL_OK\n");


        /*====================================getCardPAN Test====================================================*/
        while (getCardPAN(card) != Card_OK) {
            printf("wrong PAN, PAN IS 20 NUMBERS!\n");
        }
        printf("PAN is:%s\n", card->primaryAccountNumber);
        /* if (isValidCardPAN(card)) {
             printf("invalid card number!\n");
             return;
         }*/

         /*====================================setMaxAmount Test====================================================*/
        float maxAmount;
        printf("The maxAmount for a transaction is : ");
        scanf_s("%f", &maxAmount);

        while (setMaxAmount(terminalData, maxAmount) != TERMINAL_OK)
        {
            printf("Invalid maxAmount!\n");
            printf("The maxAmount for a transaction is : ");
            scanf_s("%f", &maxAmount);
        }

        /*====================================getTransactionAmount Test====================================================*/
        while (getTransactionAmount(terminalData) != TERMINAL_OK)
        {
            printf("Invalid Transaction Amount!\n");

        }

        /*====================================isBelowMaxAmount Test====================================================*/

        while (isBelowMaxAmount(terminalData) == EXCEED_MAX_AMOUNT) {
            printf("exceeded max amount!!\n");
            while (getTransactionAmount(terminalData) != TERMINAL_OK)
            {
                printf("Invalid Transaction Amount!\n");

            }

        }

        printf("Thank you :)");
    }
}


