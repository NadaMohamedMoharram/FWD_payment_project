#include<stdio.h>
#include "card.h"


/**************************************************************************
This function will ask for the cardholder's name and store it into card data.
Cardholder name is 24 alphabetic characters string max and 20 min.
If the cardholder name is NULL, less than 20 characters or more than 24 will return a WRONG_NAME error, else return CARD_OK.
*******************************************************************************/
EN_cardError_t getCardHolderName(ST_cardData_t* cardData)
{
    uint8_t HolderName[200];
    uint8_t NameLengthCheckCounter = 0;
    uint8_t NameIndex = 0;
    printf("Hello.Enter card holder name ,please\n");
    fgets(HolderName, 200, stdin);
    while (HolderName[NameLengthCheckCounter++] != '\0');
    NameLengthCheckCounter -= 2;   //as '/0' are two characters
    if (NameLengthCheckCounter <= 24 && NameLengthCheckCounter >= 20)
    {
        for (NameIndex = 0; NameIndex < NameLengthCheckCounter; NameIndex++)
        {
            *(cardData->cardHolderName + NameIndex) = HolderName[NameIndex];
        }
        cardData->cardHolderName[NameLengthCheckCounter] = '\0';
        return Card_OK;
    }
    else
        return WRONG_NAME;

}

/***********************************************************************************
This function will ask for the card expiry date and store it in card data.
Card expiry date is 5 characters string in the format "MM/YY", e.g "05/25".
If the card expiry date is NULL, less or more than 5 characters, or has the wrong format will return the WRONG_EXP_DATE error, else return CARD_OK.
*************************************************************************************/

EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData) {
    uint8_t CardDate[200];
    uint8_t CardDateLength = 0, DateIndex = 0;
    printf("Enter card expiry date:");
    fgets(CardDate, 200, stdin);
    while (CardDate[CardDateLength++] != '\0');
    CardDateLength -= 2;
    if (CardDateLength == 5) {
        for (DateIndex = 0; DateIndex < CardDateLength; DateIndex++)
            *(cardData->cardExpirationDate + DateIndex) = CardDate[DateIndex];
        cardData->cardExpirationDate[CardDateLength] = '\0';
        return Card_OK;
    }
    else
        return WRONG_EXP_DATE;
}


/*****************************************************************************
This function will ask for the card's Primary Account Number and store it in card data.
PAN is 20 numeric characters string, 19 character max, and 16 character min.
If the PAN is NULL, less than 16 or more than 19 characters, will return the WRONG_PAN error, else return CARD_OK.
*****************************************************************************/
EN_cardError_t getCardPAN(ST_cardData_t* cardData) {
    uint8_t CardPan[200];
    uint8_t CardPanLentgh = 0, PanIndex = 0;
    printf("Enter card primary account number: ");
    fgets(CardPan, 200, stdin);
    while (CardPan[CardPanLentgh++] != '\0');
    CardPanLentgh -= 2;
    if (CardPanLentgh == 20) {
        for (PanIndex = 0; PanIndex < CardPanLentgh; PanIndex++)
            cardData->primaryAccountNumber[PanIndex] = CardPan[PanIndex];
        cardData->primaryAccountNumber[CardPanLentgh] = '\0';
        return Card_OK;
    }
    else
        return WRONG_PAN;
}


