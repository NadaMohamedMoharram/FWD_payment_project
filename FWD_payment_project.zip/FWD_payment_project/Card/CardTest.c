#include "card.h"
#include <stdio.h>
#include <string.h>



void getCardHolderNameTest(void);
void getCardExpiryDateTest(void);
void getCardPANTest(void);

ST_cardData_t card;

void main() {
    while (1) {

        getCardHolderNameTest();
        getCardExpiryDateTest();
        getCardPANTest();

    }
}

/*==========================================================
getCardHolderName test function
============================================================*/
void getCardHolderNameTest()
{
    while (getCardHolderName(&card) != Card_OK) {
        printf("Name must be between 20 and 24 chars!\n");

    }
    printf("CardHolderName is :%s\n", card.cardHolderName);
}

/*==========================================================
getCardExpiryDate test function
============================================================*/
void getCardExpiryDateTest(void)
{
    while (getCardExpiryDate(&card) != Card_OK) {
        printf("Expiration date should be in the following form: mm/yy !\n");
    }
    printf(" Expiration date is :%s\n", card.cardExpirationDate);
}

/*==========================================================
getCardPAN test function
============================================================*/
void getCardPANTest(void)
{
    while (getCardPAN(&card) != Card_OK) {
        printf("wrong PAN, PAN IS 20 NUMBERS!\n");
    }
    printf("PAN is:%s\n", card.primaryAccountNumber);
    printf("Thnakk you :)\n");

    getchar();
}